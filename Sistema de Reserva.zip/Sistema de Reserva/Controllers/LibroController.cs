﻿using Sistema_de_Reserva.Data;
using Sistema_de_Reserva.Models;
using System;
using System.Data.SqlClient; 
using System.Windows.Forms;

namespace Sistema_de_Reserva.Controllers
{
    public class LibroController
    {
        private DatabaseHelper dbHelper = new DatabaseHelper();

        public List<Libro> ObtenerLibros()
        {
            List<Libro> libros = new List<Libro>();

            using (SqlConnection conn = dbHelper.GetConnection())
            {
                string query = "SELECT * FROM Libros";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    libros.Add(new Libro
                    {
                        ISBN = reader["ISBN"].ToString(),
                        Titulo = reader["Titulo"].ToString(),
                        Autor = reader["Autor"].ToString(),
                        Editorial = reader["Editorial"].ToString(),
                        Año = int.Parse(reader["Año"].ToString()),
                        Genero = reader["Genero"].ToString(),
                        Copias = int.Parse(reader["Copias"].ToString())
                    });
                }
            }

            return libros;
        }

        public void AgregarLibro(Libro libro)
        {
            using (SqlConnection conn = dbHelper.GetConnection())
            {
                string query = "INSERT INTO Libros (ISBN, Titulo, Autor, Editorial, Año, Genero, Copias) " +
                               "VALUES (@ISBN, @Titulo, @Autor, @Editorial, @Año, @Genero, @Copias)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ISBN", libro.ISBN);
                cmd.Parameters.AddWithValue("@Titulo", libro.Titulo);
                cmd.Parameters.AddWithValue("@Autor", libro.Autor);
                cmd.Parameters.AddWithValue("@Editorial", libro.Editorial);
                cmd.Parameters.AddWithValue("@Año", libro.Año);
                cmd.Parameters.AddWithValue("@Genero", libro.Genero);
                cmd.Parameters.AddWithValue("@Copias", libro.Copias);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
