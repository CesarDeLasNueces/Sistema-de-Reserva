﻿using Sistema_de_Reserva.Models;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_Reserva.Data
{
    public class DatabaseHelper
    {
        private string connectionString = @"Server=DESKTOP-AJ97NT6\MSSQLSERVER01;Database=BibliotecaDB;Trusted_Connection=True;";

        public SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        public bool ProbarConexion()
        {
            using (SqlConnection connection = GetConnection())
            {
                try
                {
                    connection.Open(); 
                    return true; 
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al conectar a la base de datos: " + ex.Message, "Error de Conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false; 
                }
            }
        }

        public void AgregarLibro(Libro libro)
        {
            using (SqlConnection connection = GetConnection())
            {
                connection.Open(); 

                string query = "INSERT INTO Libros (ISBN, Titulo, Autor, Editorial, Año, Genero, Copias) VALUES (@ISBN, @Titulo, @Autor, @Editorial, @Año, @Genero, @Copias)";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@ISBN", libro.ISBN);
                command.Parameters.AddWithValue("@Titulo", libro.Titulo);
                command.Parameters.AddWithValue("@Autor", libro.Autor);
                command.Parameters.AddWithValue("@Editorial", libro.Editorial);
                command.Parameters.AddWithValue("@Año", libro.Año);
                command.Parameters.AddWithValue("@Genero", libro.Genero);
                command.Parameters.AddWithValue("@Copias", libro.Copias);

                command.ExecuteNonQuery(); 
            }
        }
    }
}
