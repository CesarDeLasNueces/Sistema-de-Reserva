﻿using Sistema_de_Reserva.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_Reserva.Models
{
    public class Reserva
    {
        public int IdReserva { get; set; }
        public Usuario Usuario { get; set; }
        public Libro LibroReservado { get; set; }
        public DateTime FechaReserva { get; set; }
        public DateTime FechaRetorno { get; set; }
    }
}
