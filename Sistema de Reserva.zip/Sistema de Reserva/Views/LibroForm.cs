﻿using Sistema_de_Reserva.Data; // Asegúrate de que la referencia sea correcta
using Sistema_de_Reserva.Models; // Asegúrate de que la referencia sea correcta
using System;
using System.Windows.Forms;

namespace Sistema_de_Reserva.Views
{
    public partial class LibroForm : Form
    {
        private DatabaseHelper databaseHelper; // Instancia de DatabaseHelper

        public LibroForm()
        {
            InitializeComponent();
            databaseHelper = new DatabaseHelper(); // Inicializa la conexión a la base de datos
        }

        private void btnAgregarLibro_Click(object sender, EventArgs e)
        {
            try
            {
                Libro nuevoLibro = new Libro
                {
                    ISBN = txtISBN.Text,
                    Titulo = txtTitulo.Text,
                    Autor = txtAutor.Text,
                    Editorial = txtEditorial.Text,
                    Año = int.Parse(txtAño.Text), 
                    Genero = txtGenero.Text,
                    Copias = int.Parse(txtCopias.Text) 
                };

                databaseHelper.AgregarLibro(nuevoLibro);
                MessageBox.Show("Libro agregado correctamente."); 
                LimpiarCampos(); 
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores válidos para Año y Copias.", "Error de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error al agregar el libro: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LimpiarCampos()
        {
            txtISBN.Clear();
            txtTitulo.Clear();
            txtAutor.Clear();
            txtEditorial.Clear();
            txtAño.Clear();
            txtGenero.Clear();
            txtCopias.Clear();
        }

        private void LibroForm_Load(object sender, EventArgs e)
        {
            // Aquí puedes agregar lógica adicional si es necesaria al cargar el formulario
        }
    }
}
