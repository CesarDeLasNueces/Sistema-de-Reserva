﻿using System;
using System.Windows.Forms;

namespace Sistema_de_Reserva.Views
{
    partial class LibroForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnAgregarLibro = new Button();
            lblISBN = new Label();
            lblTitulo = new Label();
            lblAutor = new Label();
            lblEditorial = new Label();
            lblAño = new Label();
            lblGenero = new Label();
            lblCopias = new Label();
            txtISBN = new TextBox();
            txtTitulo = new TextBox();
            txtAutor = new TextBox();
            txtEditorial = new TextBox();
            txtAño = new TextBox();
            txtGenero = new TextBox();
            txtCopias = new TextBox();
            SuspendLayout();
            // 
            // btnAgregarLibro
            // 
            btnAgregarLibro.BackColor = SystemColors.ActiveCaption;
            btnAgregarLibro.Location = new Point(167, 17);
            btnAgregarLibro.Name = "btnAgregarLibro";
            btnAgregarLibro.Size = new Size(215, 40);
            btnAgregarLibro.TabIndex = 0;
            btnAgregarLibro.Text = "Agregar El Libro Aqui";
            btnAgregarLibro.UseVisualStyleBackColor = false;
            btnAgregarLibro.Click += btnAgregarLibro_Click;
            // 
            // lblISBN
            // 
            lblISBN.AutoSize = true;
            lblISBN.BackColor = Color.FromArgb(255, 224, 192);
            lblISBN.Location = new Point(12, 9);
            lblISBN.Name = "lblISBN";
            lblISBN.Size = new Size(49, 15);
            lblISBN.TabIndex = 1;
            lblISBN.Text = "00-ISBN";
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.BackColor = Color.FromArgb(255, 224, 192);
            lblTitulo.Location = new Point(12, 53);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(54, 15);
            lblTitulo.TabIndex = 2;
            lblTitulo.Text = "01-Titulo";
            // 
            // lblAutor
            // 
            lblAutor.AutoSize = true;
            lblAutor.BackColor = Color.FromArgb(255, 224, 192);
            lblAutor.Location = new Point(12, 97);
            lblAutor.Name = "lblAutor";
            lblAutor.Size = new Size(65, 15);
            lblAutor.TabIndex = 3;
            lblAutor.Text = "02-Autor@";
            // 
            // lblEditorial
            // 
            lblEditorial.AutoSize = true;
            lblEditorial.BackColor = Color.FromArgb(255, 224, 192);
            lblEditorial.Location = new Point(12, 141);
            lblEditorial.Name = "lblEditorial";
            lblEditorial.Size = new Size(67, 15);
            lblEditorial.TabIndex = 4;
            lblEditorial.Text = "03-Editorial";
            // 
            // lblAño
            // 
            lblAño.AutoSize = true;
            lblAño.BackColor = Color.FromArgb(255, 224, 192);
            lblAño.Location = new Point(12, 186);
            lblAño.Name = "lblAño";
            lblAño.Size = new Size(46, 15);
            lblAño.TabIndex = 5;
            lblAño.Text = "04-Año";
            // 
            // lblGenero
            // 
            lblGenero.AutoSize = true;
            lblGenero.BackColor = Color.FromArgb(255, 224, 192);
            lblGenero.Location = new Point(12, 225);
            lblGenero.Name = "lblGenero";
            lblGenero.Size = new Size(62, 15);
            lblGenero.TabIndex = 6;
            lblGenero.Text = "05-Genero";
            // 
            // lblCopias
            // 
            lblCopias.AutoSize = true;
            lblCopias.BackColor = Color.FromArgb(255, 224, 192);
            lblCopias.Location = new Point(12, 269);
            lblCopias.Name = "lblCopias";
            lblCopias.Size = new Size(60, 15);
            lblCopias.TabIndex = 7;
            lblCopias.Text = "06-Copias";
            // 
            // txtISBN
            // 
            txtISBN.BackColor = SystemColors.ActiveCaption;
            txtISBN.Location = new Point(12, 27);
            txtISBN.Name = "txtISBN";
            txtISBN.Size = new Size(109, 23);
            txtISBN.TabIndex = 8;
            txtISBN.Text = "Ingresar dato aqui";
            // 
            // txtTitulo
            // 
            txtTitulo.BackColor = SystemColors.ActiveCaption;
            txtTitulo.CausesValidation = false;
            txtTitulo.Location = new Point(12, 71);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(109, 23);
            txtTitulo.TabIndex = 9;
            txtTitulo.Text = "Ingrese dato aqui\r\n";
            // 
            // txtAutor
            // 
            txtAutor.BackColor = SystemColors.ActiveCaption;
            txtAutor.Location = new Point(12, 115);
            txtAutor.Name = "txtAutor";
            txtAutor.Size = new Size(109, 23);
            txtAutor.TabIndex = 10;
            txtAutor.Text = "Ingrese dato aqui";
            // 
            // txtEditorial
            // 
            txtEditorial.BackColor = SystemColors.ActiveCaption;
            txtEditorial.Location = new Point(12, 159);
            txtEditorial.Name = "txtEditorial";
            txtEditorial.Size = new Size(109, 23);
            txtEditorial.TabIndex = 11;
            txtEditorial.Text = "Ingrese dato aqui";
            // 
            // txtAño
            // 
            txtAño.BackColor = SystemColors.ActiveCaption;
            txtAño.Location = new Point(12, 199);
            txtAño.Name = "txtAño";
            txtAño.Size = new Size(109, 23);
            txtAño.TabIndex = 12;
            txtAño.Text = "Ingrese dato aqui";
            // 
            // txtGenero
            // 
            txtGenero.BackColor = SystemColors.ActiveCaption;
            txtGenero.Location = new Point(12, 243);
            txtGenero.Name = "txtGenero";
            txtGenero.Size = new Size(109, 23);
            txtGenero.TabIndex = 13;
            txtGenero.Text = "Ingrese dato aqui";
            // 
            // txtCopias
            // 
            txtCopias.BackColor = SystemColors.ActiveCaption;
            txtCopias.Location = new Point(12, 287);
            txtCopias.Name = "txtCopias";
            txtCopias.Size = new Size(154, 23);
            txtCopias.TabIndex = 14;
            txtCopias.Text = "Ingrese Numero de Copias";
            // 
            // LibroForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Info;
            ClientSize = new Size(401, 326);
            Controls.Add(txtCopias);
            Controls.Add(txtGenero);
            Controls.Add(txtAño);
            Controls.Add(txtEditorial);
            Controls.Add(txtAutor);
            Controls.Add(txtTitulo);
            Controls.Add(txtISBN);
            Controls.Add(lblCopias);
            Controls.Add(lblGenero);
            Controls.Add(lblAño);
            Controls.Add(lblEditorial);
            Controls.Add(lblAutor);
            Controls.Add(lblTitulo);
            Controls.Add(lblISBN);
            Controls.Add(btnAgregarLibro);
            Name = "LibroForm";
            Text = "Gestión de Libros";
            Load += LibroForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private Button btnAgregarLibro;
        private Label lblISBN;
        private Label lblTitulo;
        private Label lblAutor;
        private Label lblEditorial;
        private Label lblAño;
        private Label lblGenero;
        private Label lblCopias;
        private TextBox txtISBN;
        private TextBox txtTitulo;
        private TextBox txtAutor;
        private TextBox txtEditorial;
        private TextBox txtAño;
        private TextBox txtGenero;
        private TextBox txtCopias;
        // Define aquí más controles como txtTitulo, txtAutor, etc.
    }
}