using System;
using System.Windows.Forms;
using Sistema_de_Reserva.Views; 

namespace SistemaDeReserva
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LibroForm()); 
        }
    }
}